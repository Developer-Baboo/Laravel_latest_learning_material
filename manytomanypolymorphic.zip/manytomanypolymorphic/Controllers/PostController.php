<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        /* // Show Post latest comments
        $post = Post::with("latestComment")->find(1);
        Show Post oldest comments
        $post = Post::with("oldestComment")->find(1);
        return $post; */


        // 1 id ka post pa kitna tags han

        $post = Post::find(1);
        return $post->tags;


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /* $post = Post::create([
            'title' => 'News Title One',
            'description' => 'lorem sldfjs lksdjfl skdjflksd klsdjflksdjflk '
        ]);

        $post->comments()->create([
            'detail' => 'this is post comment',
        ]); */

       /*  $post = Post::create([
            'title' => 'News Title four',
            'description' => 'lorem sldfjs lksdjfl skdjflksd klsdjflksdjflk '
        ]);
        $post->tags()->create([
            "tag_name" => "skldjflsd jlksdjf ",
        ]); */

        /* $post->tags()->create([
            "tag_name" => "skldjflsd jlksdjf ",
        ]);

        $post->tags()->attach(5); */

        // post 3 ko do tag 2 and 6 attach krdo
        $post = Post::find(3);
        $post->tags()->attach([2,6]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    public function show()
    {
        $posts = Post::with("comments")->find(1);
        return $posts;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        //
    }
}
