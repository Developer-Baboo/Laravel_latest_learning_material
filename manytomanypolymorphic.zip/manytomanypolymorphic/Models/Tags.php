<?php

namespace App\Models;

use App\Models\Post;
use App\Models\Video;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Tags extends Model
{
    use HasFactory;

    protected $guarded = [];


    public $timestamps = false;

    public $table = 'taggables';


    // relationship with Video

    public function videos(){
        return $this->morphedByMany(Video::class, 'taggable');
    }



    // relationship with Post

    public function posts()
    {
        return $this->morphedByMany(Post::class, 'taggable', 'taggables', 'tags_id', 'taggable_id');
    }


}
