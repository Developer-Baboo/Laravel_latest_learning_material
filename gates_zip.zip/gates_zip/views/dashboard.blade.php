<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Dashboard</h2>
                    </div>
                    <div class="card-body">
                        <p class="mb-3" >Welcome, {{ Auth::user()->name }}!</p>
                        {{-- we can do same work of allows with can function, we add mutliple tags inside alllows and can method. cannt function is oppsite of can function --}}
                        {{-- @if (Gate::allows('isAdmin'))
                            <a href="#" class="btn btn-success">Admin Panel</a>
                        @endif --}}
                        @can('isAdmin')
                            <a href="#" class="btn btn-success">Admin Panel</a>
                        @else
                            <a href="#" class="btn btn-success">Other Links</a>
                        @endcan
                        <a href="{{ route('profile.show', Auth::id()) }}" class="btn btn-primary">Profile</a>
                        <a href="{{ route('post.show', Auth::id()) }}" class="btn btn-warning">Post</a>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-danger">Logout</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
