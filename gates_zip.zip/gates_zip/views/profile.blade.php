<!DOCTYPE html>
<html>
<head>
    <title>Profile Page</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="card mt-4">
                    <div class="card-header">
                        <h3>Profile Page</h3>
                    </div>
                    <div class="card-body">
                        <table class="table" >
                            <tr>
                                <td>Name</td>
                                <td>{{$user->name}}</td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>{{$user->email}}</td>
                            </tr>
                            <tr>
                                <td>Age</td>
                                <td>{{$user->age}}</td>
                            </tr>
                        </table>
                        <a href="{{route('dashboard')}}" class="btn btn-dark">Back</a>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</body>
</html>
