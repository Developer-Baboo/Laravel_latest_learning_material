<!DOCTYPE html>
<html>
<head>
    <title>Profile Page</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-8">
                <div class="card mt-4">
                    <div class="card-header">
                        <h3>Posts</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <tr>
                               <th>ID</th>
                               <th>Title</th>
                               <th>Description</th>
                               <th>Update</th>
                               <th>Delete</th>
                            </tr>
                            {{-- @foreach($posts as $post) --}}
                            @foreach($post as $post)
                                <tr>
                                    <td>{{ $post->id }}</td>
                                    <td>{{ $post->title }}</td>
                                    <td>{{ $post->description }}</td>
                                    <td><a href="{{ route('post.update', $post->id) }}" class="btn btn-primary">Update</a></td>
                                    <td><a href="#" class="btn btn-danger">Delete</a></td>
                                </tr>
                            @endforeach
                        </table>
                        <a href="{{route('dashboard')}}" class="btn btn-dark">Back</a>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</body>
</html>
