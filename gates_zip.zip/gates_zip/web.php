<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [UserController::class, 'loginPage'])->name('home');
Route::post('/login', [UserController::class, 'login'])->name('login');
Route::get('register', [UserController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [UserController::class, 'register']);
Route::post('/logout', [UserController::class, 'logout'])->name('logout');
// Route::get('/dashboard', [UserController::class, 'dashboardPage'])->name('dashboard')->middleware('can:isAdmin'); // only admin can access this route, we can add multiple gate conditions
// Route::get('/dashboard', [UserController::class, 'dashboardPage'])->name('dashboard')->can('isAdmin'); // we can write gate in this way
Route::get('/dashboard', [UserController::class, 'dashboardPage'])->name('dashboard');
Route::get('/profile/{id}', [UserController::class, 'viewProfile'])->name('profile.show');
Route::get('/post/{id}', [UserController::class, 'viewPost'])->name('post.show');

Route::get('/post/update/{postid}', [UserController::class, 'UpdatePost'])->name('post.update');



























