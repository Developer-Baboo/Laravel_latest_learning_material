<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function index(){
         // Fetch all session data
        /* $value = session()->all();
        echo "<pre>";
            print_r($value);
        echo "</pre>"; */

        // set default of session
        $value = session('name', 'Hello');
        echo $value;

        // to get session particular data by passing key
        // $value = session()->get('name');
        // $value = session('name');
        // echo $value;
    }

   /*  public function storeSession(Request $request){
        $request->session(['name' => 'Baboo Kumar']); // will not store it, for that we have to use put method
        $request->session()->put('class', 'Btech');
        $request->session()->put('age', 'twenty');
        $request->session()->put('gender', 'male');
    } */

    public function storeSession(){
        session([
            'name' => 'Baboo Kumar',
            'Class' => 'btech'
        ]);

        /*
        session()->put('class', 'Btech');
        session()->put('age', 'twenty'); */

        return redirect('/');
    }


    public function deleteSession(){
        /* session()->forget('name');
        session()->forget('email');
        session()->forget('class');
        session()->forget('age');
        session()->forget('gender'); */
        session()->flush(); // ya sb ko remove krdaga
        return redirect('/');
    }

}
