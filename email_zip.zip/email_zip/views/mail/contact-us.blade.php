<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h3>Hello Admin</h3>
<p>Name: {{ $request['name'] }}</p>
<p>email: {{ $request['email'] }}</p>
<p>subject: {{ $request['subject'] }}</p>
<p>message: {{ $request['message'] }}</p>
{{-- Email Attachment Automatically aajaygi --}}
</body>
</html>
