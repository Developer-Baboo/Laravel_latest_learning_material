<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{$subject}}</title>
</head>
<body>
    <h3>{{ $subject }}</h3>
    <p>{{ $mailmessage }}</p>
    {{-- <p>{{ $details['name'] }}</p>
    <p>{{ $details['product'] }}</p>
    <p>{{ $details['price'] }}</p> --}}

    <p>{{ $name }}</p>
    <p>{{ $product }}</p>
    <p>{{ $price }}</p>
</body>
</html>
