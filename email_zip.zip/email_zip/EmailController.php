<?php

namespace App\Http\Controllers;

use App\Mail\sendemail;
use App\Mail\welcomeemail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    public function sendEmail(){
        $toEmail = "finejquery@gmail.com";
        $message = "Hello, Welcome to our website";
        $subject = "Welcome to our website";

        $moreuser = "Go@gmail.com";
        $details = [
            'name' => 'Baboo Kumar',
            'product' => 'Test Product',
            'price' => 123456,
        ];
        /*
        multiple users ko ek he message send krna ho to, agr email thousands man hoon to hum attachments use krta han
        $email = [
            'user@gmail.com',
            'user1@gmail.com',
            'user2@gmail.com',
        ];
        foreach($email as $reception){
            Mail::to($reception)->send(new welcomeemail($message, $subject));
        } */
        $request = Mail::to($toEmail)->cc($moreuser)->send(new welcomeemail($message, $subject, $details));
        dd($request);
    }


    public function contactForm(){
        return view('contact-form');
    }

    public function sendContactEmail(Request $request){
        request()->validate([
            'name' =>'required',
            'email' =>'required',
           'subject' =>'required',
           'message' =>'required',
           'attachment' => 'required|mimes:pdf,doc,xls,xlsx,png,jpg,jpeg,txt|max:2048' // 2 MB data size
        ]);
        $fileName = time() . "." . $request->file('attachment')->extension();
        $request->file('attachment')->move('uploads', $fileName);
        // dd($fileName);
        $adminEmail = 'babooheerani@gmail.com';
        $response = Mail::to($adminEmail)->send(new sendemail($request->all(), $fileName));
        if($response){
            return back()->with('success', 'Thanks for contacting us!');
        }else{
            return back()->with('error', 'Something went wrong!');
        }
    }
}
