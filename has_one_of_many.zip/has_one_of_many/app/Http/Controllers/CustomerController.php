<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $customers = Customer::with("latestOrder")->get();
        // $customers = Customer::with("oldestOrder")->get();
        // $customers = Customer::with("smallestOrder")->find(1);
        $customers = Customer::with("largestOrder")->find(1);
        // $customers = Customer::with("smallestOrder")->get();
        // $customers = Customer::with("latestOrder")->find(2);
        /* foreach($customers as $customer){
            echo "Customer name => ".$customer->name."<br />";
            echo "Latest Order Id => ".$customer->latestOrder->id."<br />";
            echo "Order Amount => ".$customer->latestOrder->amount."<br />";
            echo "<hr >";
        } */
        /* foreach($customers as $customer){
            echo "Customer name => ".$customer->name."<br />";
            echo "Oldest Order Id => ".$customer->oldestOrder->id."<br />";
            echo "Order Amount => ".$customer->oldestOrder->amount."<br />";
            echo "<hr >";
        } */
       
       /*  echo "Customer name => ".$customers->name."<br />";
        echo "Smallest Order Id => ".$customers->smallestOrder->id."<br />";
        echo "Order Amount => ".$customers->smallestOrder->amount."<br />"; */


        echo "Customer name => ".$customers->name."<br />";
        echo "Largest Order Id => ".$customers->largestOrder->id."<br />";
        echo "Order Amount => ".$customers->largestOrder->amount."<br />";
        
        // return $customers;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Customer $customer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        //
    }
}
