<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    // Register user route
    public function register(Request $request)
    {
        // Validate the incoming request data
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);


        // dd($data);

        // Hash the password before saving
        $data['password'] = Hash::make($data['password']);

        // Create the user
        $user = User::create($data);

        // Check if the user was created successfully
        if ($user) {
            return redirect()->route('login')->with('success', 'Registration successful!');
        } else {
            return back()->withErrors(['msg' => 'Failed to register user. Please try again.']);
        }
    }

    // login user route
    public function login(Request $request){
        // Validate the incoming request data
        $data = $request->validate([
            'email' =>'required|string|email|max:255',
            'password' => 'required|string|min:8',
        ]);

        // Attempt to authenticate the user
        /* if(Auth::attempt($data)){

        } */
        if (auth()->attempt($data)) {
            return redirect()->route('dashboard')->with('success', 'Login successful!');
        } else {
            return back()->withErrors(['msg' => 'Invalid credentials. Please try again.']);
        }
    }

    // dashboard route
    public function dashboardPage(){
        // We don't need to use Check again and again, if we use only middleware at that place
        return view('dashboard');
    }

    // logout user route
    public function logout(){
        Auth::logout();
        return view('login')->with('success', 'Logout successful!');
    }



    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
