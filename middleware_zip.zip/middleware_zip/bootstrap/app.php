<?php

use App\Http\Middleware\TestUser;
use App\Http\Middleware\ValidUser;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'IsUserValid' => ValidUser::class
        ]);

        // 2 Middlwares ka group whose name is ok-user
        // $middleware->appendToGroup('ok-user', [
        //     ValidUser::class,
        //     TestUser::class,
        // ]);

        // appendTo and PrependTo both are same
        // $middleware->prependToGroup('ok-user', [
        //     ValidUser::class,
        //     TestUser::class,
        // ]);


        // Global Middleware sb routes pa chlaga
        // $middleware->append(TestUser::class);

        // Pass multiple middlewares
        $middleware->use([
            TestUser::class,
            ValidUser::class,
        ]);// passs multiple middlewares

    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
