<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class ValidUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        echo "<h3 class='text-primary'>We are now in ValidUser Middleware</h3>";
        // ya role ke value route sa arhi ha
        // echo "<h3 class='text-primary'>".$role."</h3>";
        // Agr user auhenticated ha to phir jis page ko request kr rha ha wo show hoga
        if(Auth::user()->role == 'admin'){
            return $next($request);
        }else if(Auth::user()->role == 'reader'){
            return redirect()->route('reader');
        }else{
            return redirect()->route('login')->with('error', 'You are not authorized or admin to access Dashboard');;
        }
        // below code kaleya hum ko route is trha define krna praga Route::get('dashboard', [UserController::class, 'dashboardPage'])->name('dashboard')->middleware(['IsUserValid:admin', TestUser::class]);
        // if(Auth::check() && Auth::user()->role == 'admin'){
        //     return $next($request);
        // }else{
        //     return redirect()->route('login')->with('error', 'You are not authorized or admin to access Dashboard');;
        // }
    }

    // jb user ke request complete hojati ha phir ya necha wala method chlta ha
    public function terminate(Request $request, Response $response): void
    {
        // echo "<h3 class='text-danger'>We are now Terminating ValidUser Middleware</h3>";
    }
}
