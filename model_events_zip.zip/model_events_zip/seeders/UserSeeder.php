<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = collect([
            [
                'name' => 'Test User1',
                'email' => 'test1@example.com',
                'password' => 'Test User1',
            ],
            [
                'name' => 'Test User2',
                'email' => 'test2@example.com',
                'password' => 'Test User1',
            ],
            [
                'name' => 'Test User3',
                'email' => 'test3@example.com',
                'password' => 'Test User1',
            ],
            [
                'name' => 'Test User4',
                'email' => 'test4@example.com',
                'password' => 'Test User1',
            ]
        ]);
        $users->each(function ($user) {
            User::insert($user);
        });
    }
}
