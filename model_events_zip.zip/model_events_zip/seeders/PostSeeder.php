<?php

namespace Database\Seeders;

use App\Models\Post;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $posts = collect([
            [
                'title' => 'New Title One',
                'slug' => 'news-title-one',
                'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo consequuntur aut ab expedita sint sequi autem consectetur quaerat eum recusandae dolores quam exercitationem possimus, voluptatum tenetur delectus iure dolor minus!',
                'user_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'New Title Two',
                'slug' => 'news-title-two',
                'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo consequuntur aut ab expedita sint sequi autem consectetur quaerat eum recusandae dolores quam exercitationem possimus, voluptatum tenetur delectus iure dolor minus!',
                'user_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'New Title Three',
                'slug' => 'news-title-three',
                'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo consequuntur aut ab expedita sint sequi autem consectetur quaerat eum recusandae dolores quam exercitationem possimus, voluptatum tenetur delectus iure dolor minus!',
                'user_id' => 3,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'New Title Four',
                'slug' => 'news-title-four',
                'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo consequuntur aut ab expedita sint sequi autem consectetur quaerat eum recusandae dolores quam exercitationem possimus, voluptatum tenetur delectus iure dolor minus!',
                'user_id' => 4,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
        $posts->each(function ($post) {
            Post::insert($post);
        });
    }
}
