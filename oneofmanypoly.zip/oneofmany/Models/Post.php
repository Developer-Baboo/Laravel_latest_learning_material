<?php

namespace App\Models;

use App\Models\Comment;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Post extends Model
{
    use HasFactory;
    protected $guarded = [];
    public function comments(){
        return $this->morphMany(Comment::class, 'commentable');
    }


    public function latestComment(){
        return $this->morphOne(Comment::class, 'commentable')
                    ->latestOfMany();
    }

    public function oldestComment(){
        return $this->morphOne(Comment::class, 'commentable')
                    ->oldestOfMany();
    }

}
