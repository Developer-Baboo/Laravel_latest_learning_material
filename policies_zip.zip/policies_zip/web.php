<?php

use App\Http\Controllers\BookController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

Route::get('/', [UserController::class, 'loginPage'])->name('home');
Route::post('/login', [UserController::class, 'login'])->name('login');
Route::get('register', [UserController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [UserController::class, 'register']);
Route::post('/logout', [UserController::class, 'logout'])->name('logout');
// Route::get('/book', [BookController::class, 'bookPage'])->name('book');

Route::get('/books', [BookController::class, 'index'])->name('books.index')->middleware('auth');
Route::get('/books/create', [BookController::class, 'create'])->name('books.create')->middleware('auth');
Route::post('/books', [BookController::class, 'store'])->name('books.store')->middleware('auth');
Route::get('/books/{id}/edit', [BookController::class, 'edit'])->name('books.edit')->middleware('auth');
Route::put('/books/{id}/update', [BookController::class, 'update'])->name('books.update')->middleware('auth');
Route::get('/books/{id}/show', [BookController::class, 'show'])->name('books.show')->middleware('auth');
Route::delete('/books/delete/{id}', [BookController::class, 'destroy'])->name('books.destroy')->middleware('auth');


