<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="card mt-4">
                    <div class="card-header">
                        <h3>Show Book Page</h3>
                    </div>
                    <div class="card-body">
                        <table class="table" >
                            <tr>
                                <td>Title</td>
                                <td>{{$book->title}}</td>
                            </tr>
                            <tr>
                                <td>Price</td>
                                <td>{{$book->price}}</td>
                            </tr>

                        </table>
                        <a href="{{route('books.index')}}" class="btn btn-dark">Back</a>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</body>
</html>
