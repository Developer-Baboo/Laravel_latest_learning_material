{{-- resources/views/login.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <title>Create Book Page</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Add Book</h2>
                    </div>
                    <div class="card-body">
                        {{-- {{ route('add') }} --}}
                        <form method="POST" action="{{ route('books.store') }}">
                            {{-- @method('POST') --}}
                            @csrf
                            <div class="form-group">
                                <label for="title">Title:</label>
                                <input type="title" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="form-group">
                                <label for="price">Price:</label>
                                <input type="price" class="form-control" id="price" name="price" required>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
