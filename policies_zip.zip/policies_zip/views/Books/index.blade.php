<!DOCTYPE html>
<html>
<head>
    <title>Book Page</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-4">
        <div>
            <h1>My Books</h1>
            <h1>Hello, {{ Auth::user()->name }}!</h1>
        </div>
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif
        <div class="row mb-3">
            <div class="col">
                <a href="{{ route('books.create') }}" class="btn btn-primary">Add Book</a>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <div>
                    <button class="btn btn-secondary">logout</button>
                </div>
            </form>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Price</th>
                    <th>Edit</th>
                    <th>View</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($books as $book )
                <tr>
                    <td>{{$book->title}}</td>
                    <td>{{$book->price}}</td>
                    <td><a href="{{ route('books.edit', $book->id) }}" class="btn btn-warning btn-sm">Edit</a></td>
                    <td><a href="{{ route('books.show', $book->id) }}"  class="btn btn-info btn-sm">View</a></td>
                    <td>
                        <form action="{{ route('books.destroy', $book->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this book?')">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
