{{-- resources/views/login.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <title>Update Book Page</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Update Book</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('books.update', $book->id) }}">
                            @method('PUT')
                            @csrf
                            <div class="form-group">
                                <label for="title">Title:</label>
                                <input type="title" value="{{$book->title}}"  class="form-control" id="title" name="title" required>
                            </div>
                            <div class="form-group">
                                <label for="price">Price:</label>
                                <input type="price" value="{{$book->price}}" class="form-control" id="price" name="price" required>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
