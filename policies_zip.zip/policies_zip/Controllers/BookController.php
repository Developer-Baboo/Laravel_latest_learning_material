<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class BookController extends Controller
{

   /*  public function bookPage(){
        $books = Book::all();
        return view('book', compact('books'));
    } */
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Get the authenticated user
        $user = Auth::user();

        // Retrieve all books
        $allBooks = Book::all();

        // Filter books using the policy
        $books = $allBooks->filter(function ($book) use ($user) {
            return Gate::forUser($user)->allows('view', $book);
        });

        return view('Books.index', compact('books'));
    }

    public function create()
    {
        return view('Books.create');
    }

    public function store(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'title' => 'required|string|max:255',
            'price' => 'required|numeric',
        ]);

        // Create a new book
        $book = new Book();
        $book->title = $request->input('title');
        $book->price = $request->input('price');
        $book->user_id = Auth::user()->id;
        $book->save();

        // Redirect back to the books index page with a success message
        return redirect()->route('books.index')->with('success', 'Book added successfully.');
    }


    /**
     * Display the specified resource.
     */
    public function show(Book $book, int $id)
    {
        /* Gate::authorize('view', $book);
        // $book = Book::find($id);
        // dd($book);
        return view('Books.show', compact('book')); */

        // $user = auth()->user();
        // dd($book);
        // if ($user->id !== 4) {
        //     abort(403, 'Unauthorized actionsdfsdf.');
        // }

        $book = Book::find($id);
        Gate::authorize('view', $book);
        // dd($book);
        return view('Books.show', compact('book'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Book $book, int $id)
    {
        $book = Book::find($id);
        return view('Books.edit', compact('book'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, int $id, Book $book)
    {
        // Find the book by ID
        $book = Book::findOrFail($id);
        Gate::authorize('update', $book);
        // Validate the incoming request
        $request->validate([
            'title' => 'required|string|max:255',
            'price' => 'required|numeric',
        ]);

        // Update the book attributes
        $book->title = $request->input('title');
        $book->price = $request->input('price');
        $book->save();

        // Redirect back to the books index page with a success message
        return redirect()->route('books.index')->with('success', 'Book updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Book $book, int $id)
    {
        $book = Book::find($id);
        Gate::authorize('delete', $book);
        $book->delete();
        return redirect()->route('books.index')->with('success', 'Book deleted successfully.');
    }
}
