<?php

namespace App\Models;

use App\Models\Post;
use App\Models\Country;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class User extends Model
{
    use HasFactory;
    
     // relationship
     public function phoneNumber(){
        return $this->hasOneThrough(Phone_number::class, Company::class);
    }

    public function company(){
        return $this->hasOne(Company::class);
    }


    // Konse user ka kitne posts likhhe han
    public function posts(){
        return $this->hasMany(Post::class);
    }

    public function country(){
        return $this->belongsTo(Country::class);
    }
}
