<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Laravel Authentication</h1>
        <div class="row mt-5">
            <div class="col">
                <a href="{{ route('register') }}" class="btn btn-primary mx-2">Register | </a>
                <a href="{{ route('login') }}" class="btn btn-secondary mx-2">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
