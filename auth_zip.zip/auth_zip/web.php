<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

Route::get('/', function () {
    return view('welcome');
});

Route::view('register', 'register')->name('register');
Route::post('registerSave', [UserController::class, 'register'])->name('registerSave');
Route::post('loginSave', [UserController::class, 'login'])->name('loginSave');
Route::view('login', 'login')->name('login');
Route::get('dashboard', [UserController::class, 'dashboardPage'])->name('dashboard');
Route::get('logout', [UserController::class, 'logout'])->name('logout');
// Route::view('')
