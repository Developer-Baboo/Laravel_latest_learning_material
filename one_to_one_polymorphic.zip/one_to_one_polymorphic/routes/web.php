<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ImageController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\CustomerController;

Route::get('/', function () {
    return view('welcome');
});

// Route::resource('user', UserController::class);


// Route::resource('customer', CustomerController::class);
// Route::resource('order', OrderController::class);

// 
/* Route::resource('country', CountryController::class);
Route::resource('user', UserController::class);
Route::resource('post', PostController::class); */


Route::resource('user', UserController::class);
Route::resource('post', PostController::class);
Route::resource('image', ImageController::class);















