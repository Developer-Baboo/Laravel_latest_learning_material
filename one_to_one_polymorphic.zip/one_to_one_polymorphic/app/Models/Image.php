<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    use HasFactory;

    protected $guarded = [];
    public $timestamps = false;

    // function name should be same with prefix of i and type column in images table
    public function imageable(){
        return $this->morphTo();
        // return $this->morphTo(__FUNCTION__, 'imageable_type', 'imageable_id'); agr ap na ya 2 column database man nhi bnia han
    }
}
